document.getElementById('signupForm').addEventListener('submit', function (e) {
  e.preventDefault();

  const errorElements = document.querySelectorAll('.required-error');
  errorElements.forEach(el => (el.textContent = ''));

  let valid = true;

  const firstName = this.firstName.value.trim();
  if (!firstName) {
    document.getElementById('firstName-error').textContent = 'required';
    valid = false;
  }

  const lastName = this.lastName.value.trim();
  if (!lastName) {
    document.getElementById('lastName-error').textContent = 'required';
    valid = false;
  }

  const sexInputs = this.querySelectorAll('input[name="sex"]');
  let sexValue = '';
  for (const radio of sexInputs) {
    if (radio.checked) {
      sexValue = radio.value;
      break;
    }
  }
  if (!sexValue) {
    document.getElementById('sex-error').textContent = 'required';
    valid = false;
  }

  const email = this.email.value.trim();
  if (!email) {
    document.getElementById('email-error').textContent = 'required';
    valid = false;
  }

  const password = this.password.value.trim();
  if (!password) {
    document.getElementById('password-error').textContent = 'required';
    valid = false;
  }

  const supportReason = this.supportReason.value.trim();
  if (!supportReason) {
    document.getElementById('supportReason-error').textContent = 'required';
    valid = false;
  }

  if (!valid) return;

  // Save to localStorage
  localStorage.setItem('firstName', firstName);
  localStorage.setItem('lastName', lastName);
  localStorage.setItem('sex', sexValue);
  localStorage.setItem('email', email);
  localStorage.setItem('supportReason', supportReason);

  window.location.href = 'proj_profile_Libardos.html';
});
